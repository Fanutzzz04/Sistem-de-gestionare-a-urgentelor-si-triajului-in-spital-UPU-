import bcrypt
from flask import Flask, render_template, request, redirect, url_for, session, flash
from app.db import run_select, run_execute, run_insert

app = Flask(__name__, template_folder='flask_app/templates', static_folder='flask_app/static')
app.secret_key = "MED_SYS_2026_ETAPA_7_8_9_10_FINAL"

CRUD_CONFIG = {
    "users": {
        "label": "Echipă Medicală", "icon": "fa-user-nurse",
        "pk": "id",
        "list_fields": ["id", "username", "email", "specializare"],
        "create_fields": ["username", "email", "password", "specializare"],
        "update_fields": ["username", "email", "password", "specializare"],
        "default_sort": "id ASC",
        "allow_edit": False,
        "allow_delete": False
    },
    "pacienti": {
        "label": "Pacienți", "icon": "fa-hospital-user",
        "pk": "Id_pacient",
        "list_fields": ["Id_pacient", "Nume", "Prenume", "CNP"],
        "default_sort": "Id_pacient DESC",
        "create_fields": ['Nume', 'Prenume', 'CNP', 'Observatii', 'sectia_selectata', 'cabinet_selectat'],
        "update_fields": ['Nume', 'Prenume', 'CNP', 'Observatii', 'sectia_selectata', 'cabinet_selectat'],
        "allow_edit": True,
        "allow_delete": True
    },
    "Vizite_urgente": {
        "label": "Urgențe", "icon": "fa-ambulance",
        "pk": "Id_vizita",
        "list_fields": ["Id_vizita", "id_pacient", "Mod_prezentare", "Data_ora_sosirie"],
        "create_fields": ["id_pacient", "Mod_prezentare"],
        "update_fields": ["Mod_prezentare"],
        "fk_dropdowns": {"id_pacient": ("pacienti", "Id_pacient", "Nume")},
        "default_sort": "Id_vizita DESC",
        "allow_edit": True,
        "allow_delete": True
    },
    # BLOCAT COMPLET PENTRU EDITARE/ȘTERGERE/ADĂUGARE (READ-ONLY)
    "Administrare_Medicamente": {
        "label": "Administrare Medicamente", "icon": "fa-capsules",
        "pk": "id_administrare",
        "list_fields": ["id_administrare", "id_vizita", "nume_medicament", "doza", "unitate_masura"],
        "create_fields": [],
        "update_fields": [],
        "default_sort": "id_administrare DESC",
        "allow_edit": False,  # Ascunde butoanele de editare și blochează ruta
        "allow_delete": False,  # Ascunde butoanele de ștergere și blochează ruta
        "allow_create": False  # Elimină butonul de adăugare din listă
    }
}


@app.before_request
def security_manager():
    """Gestionează accesul în funcție de starea bazei și a sesiunii."""
    public_routes = ['login', 'static', 'setup', 'seed_admin']
    if request.endpoint in public_routes:
        return

    try:
        count = run_select("SELECT COUNT(*) FROM users")[0][0]
        if count == 0:
            return redirect(url_for('setup'))
    except Exception:
        pass

    if 'user' not in session:
        return redirect(url_for('login'))


@app.context_processor
def global_vars():
    return dict(crud_config=CRUD_CONFIG, logged_in='user' in session)


@app.route("/setup")
def setup():
    return render_template("setup_required.html")


@app.route("/seed-admin")
def seed_admin():
    """Injectează sau resetează administratorul pentru testare."""
    hashed_pwd = bcrypt.hashpw("spital2026".encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

    check = run_select("SELECT COUNT(*) FROM users WHERE username=%s", ("admin_spital",))

    if check[0][0] == 0:
        run_insert("INSERT INTO users (username, email, password, specializare) VALUES (%s, %s, %s, %s)",
                   ("admin_spital", "admin@spital.ro", hashed_pwd, "Administrator Sistem"))
        flash("Cont creat: admin_spital / spital2026", "success")
    else:
        run_execute("UPDATE users SET password=%s WHERE username=%s", (hashed_pwd, "admin_spital"))
        flash("Parola resetată pentru admin_spital: spital2026", "info")

    return redirect(url_for('login'))


@app.route("/login", methods=["GET", "POST"])
def login():
    if 'user' in session: return redirect(url_for('index'))
    error = None
    if request.method == "POST":
        u = request.form.get("username").strip()
        p = request.form.get("password").strip()

        res = run_select("SELECT password, username FROM users WHERE username=%s", (u,))

        try:
            if res and bcrypt.checkpw(p.encode('utf-8'), res[0][0].encode('utf-8')):
                session.clear()
                session['user'] = res[0][1]
                return redirect(url_for('index'))
            else:
                error = "Utilizator sau parolă incorectă!"
        except ValueError:
            error = "Eroare format parolă în DB (Invalid Salt). Rulează /seed-admin!"

    return render_template("login.html", error=error)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for('login'))


@app.route("/")
def index():
    counts = {
        "users": run_select("SELECT COUNT(*) FROM users")[0][0],
        "pacienti": run_select("SELECT COUNT(*) FROM pacienti")[0][0],
        "Vizite_urgente": run_select("SELECT COUNT(*) FROM Vizite_urgente")[0][0],
        "medicamente": run_select("SELECT COUNT(*) FROM Administrare_Medicamente")[0][0],
        "critici": run_select(
            "SELECT COUNT(*) FROM Vizite_urgente WHERE diagnostic LIKE '%critic%' OR diagnostic LIKE '%stop%' OR diagnostic LIKE '%resuscitare%'")[
            0][0]
    }

    sql_sectii = "SELECT UPPER(sectia_selectata), COUNT(*) FROM pacienti WHERE sectia_selectata IS NOT NULL AND sectia_selectata != '' GROUP BY UPPER(sectia_selectata)"
    res_sectii = run_select(sql_sectii)

    sectii_data = []
    max_val = 1

    for row in res_sectii:
        val = row[1]
        if val > max_val: max_val = val
        sectii_data.append({'label': row[0], 'count': val})

    sql_sosiri = "SELECT Mod_prezentare, COUNT(*) FROM Vizite_urgente WHERE Mod_prezentare IS NOT NULL GROUP BY Mod_prezentare"
    res_sosiri = run_select(sql_sosiri)

    sosiri_labels = [row[0] for row in res_sosiri]
    sosiri_valori = [row[1] for row in res_sosiri]

    return render_template(
        "index.html",
        counts=counts,
        sectii_data=sectii_data,
        max_sectie=max_val,
        sosiri_labels=sosiri_labels,
        sosiri_valori=sosiri_valori
    )


@app.route("/search", methods=["GET"])
def global_search():
    query = request.args.get("query", "").strip()
    table_target = request.args.get("table", "").strip()
    filter_by = request.args.get("filter_by", "").strip()

    results = {}

    if table_target and filter_by and query:
        if table_target == "pacienti":
            sql = "SELECT Id_pacient, Nume, Prenume, CNP, Observatii, sectia_selectata, cabinet_selectat FROM pacienti WHERE " + filter_by + " LIKE %s"
            rows = run_select(sql, (f"%{query}%",))
            results["pacienti"] = rows
        elif table_target == "Vizite_urgente":
            sql = f"SELECT Id_vizita, id_pacient, diagnostic, Mod_prezentare FROM Vizite_urgente WHERE {filter_by} LIKE %s"
            rows = run_select(sql, (f"%{query}%",))
            results["Vizite_urgente"] = rows

        return render_template("search_results.html", results=results, query=query, mode="specific")

    if query:
        parts = query.split()
        if len(parts) >= 2:
            sql_pacienti = """
                           SELECT Id_pacient, Nume, Prenume, CNP, Observatii, sectia_selectata, cabinet_selectat
                           FROM pacienti
                           WHERE (Nume LIKE %s AND Prenume LIKE %s) \
                              OR (Prenume LIKE %s AND Nume LIKE %s)
                           """
            params = (f"%{parts[0]}%", f"%{parts[1]}%", f"%{parts[0]}%", f"%{parts[1]}%")
        else:
            sql_pacienti = """
                           SELECT Id_pacient, Nume, Prenume, CNP, Observatii, sectia_selectata, cabinet_selectat
                           FROM pacienti
                           WHERE Nume LIKE %s \
                              OR Prenume LIKE %s \
                              OR CNP LIKE %s
                           """
            params = (f"%{query}%", f"%{query}%", f"%{query}%")

        pacienti_gasiti = run_select(sql_pacienti, params)
        results["pacienti"] = pacienti_gasiti

        if pacienti_gasiti:
            ids_pacienti = [str(p[0]) for p in pacienti_gasiti]
            format_strings = ','.join(['%s'] * len(ids_pacienti))

            sql_vizite = f"""
                SELECT v.Id_vizita, p.Nume, p.Prenume, v.diagnostic, v.Mod_prezentare 
                FROM Vizite_urgente v
                JOIN pacienti p ON v.id_pacient = p.Id_pacient
                WHERE v.id_pacient IN ({format_strings})
                ORDER BY v.Id_vizita DESC
            """
            results["vizite"] = run_select(sql_vizite, tuple(ids_pacienti))

    return render_template("search_results.html", results=results, query=query, mode="global")


@app.route("/crud/<table>")
def crud_list(table):
    conf = CRUD_CONFIG[table]
    fields_to_select = list(conf['list_fields'])

    if table == 'pacienti':
        sql = """
              SELECT p.Id_pacient, p.Nume, p.Prenume, p.CNP, v.Mod_prezentare, p.sectia_selectata, p.cabinet_selectat
              FROM pacienti p
                       LEFT JOIN Vizite_urgente v ON p.Id_pacient = v.id_pacient
              ORDER BY p.Id_pacient DESC
              """
        fields_for_mapping = ['Id_pacient', 'Nume', 'Prenume', 'CNP', 'Mod_prezentare', 'sectia_selectata',
                              'cabinet_selectat']
    else:
        sql = f"SELECT {', '.join(fields_to_select)} FROM {table} ORDER BY {conf['default_sort']}"
        fields_for_mapping = fields_to_select

    rows = run_select(sql)
    col_map = {name: index for index, name in enumerate(fields_for_mapping)}

    return render_template("crud_list.html", table=table, config=conf, rows=rows, col_map=col_map)


@app.route("/crud/<table>/create", methods=["GET", "POST"])
def crud_create(table):
    conf = CRUD_CONFIG[table]

    # PROTECȚIE BACKEND: Blocăm accesul dacă tabela are crearea interzisă
    if conf.get("allow_create") is False:
        flash(f"Acțiune neautorizată! Adăugarea directă în tabela '{conf['label']}' este interzisă.", "danger")
        return redirect(url_for('crud_list', table=table))

    if request.method == "POST":
        cols = conf["create_fields"]
        vals = [request.form.get(c) for c in cols]

        if table == "pacienti" and (not vals[cols.index("CNP")] or len(str(vals[cols.index("CNP")])) != 13):
            flash("CNP-ul trebuie să aibă 13 cifre!", "danger")
            return redirect(url_for('crud_create', table=table))

        if table == "users":
            idx = cols.index("password")
            vals[idx] = bcrypt.hashpw(vals[idx].encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

        new_id = run_insert(f"INSERT INTO {table} ({', '.join(cols)}) VALUES ({', '.join(['%s'] * len(cols))})",
                            tuple(vals))

        if table == 'pacienti':
            mod_prezentare = request.form.get('Mod_prezentare', 'Mijloace Proprii')
            sectia = request.form.get('sectia_selectata', 'CHIRURGIE')
            cabinet = request.form.get('cabinet_selectat', '')

            insert_vizita_sql = """
                                INSERT INTO Vizite_urgente (id_pacient, Mod_prezentare, Data_ora_sosirie, diagnostic)
                                VALUES (%s, %s, NOW(), %s)
                                """
            diag_initial = f"Direcționat prin Triaj-3D la secția {sectia} ({cabinet})" if cabinet else "Triaj inițial efectuat"
            run_insert(insert_vizita_sql, (new_id, mod_prezentare, diag_initial))

        flash("Adăugat cu succes!", "success")
        return redirect(url_for('crud_list', table=table))

    fk = {f: run_select(f"SELECT {r[1]}, {r[2]} FROM {r[0]}") for f, r in conf.get("fk_dropdowns", {}).items()}
    return render_template("crud_form.html", table=table, config=conf, fk_options=fk, row=None)


@app.route("/crud/<table>/edit/<int:id>", methods=["GET", "POST"])
def crud_edit(table, id):
    conf = CRUD_CONFIG[table]

    if conf.get("allow_edit") is False:
        flash(f"Acțiune neautorizată! Modificarea înregistrărilor din tabela '{conf['label']}' este interzisă.",
              "danger")
        return redirect(url_for('crud_list', table=table))

    pk = conf.get("pk", "id")

    if request.method == "POST":
        cols = conf["update_fields"]
        vals = [request.form.get(c) for c in cols]

        if table == "users" and vals[cols.index("password")] and not vals[cols.index("password")].startswith("$2b$"):
            vals[cols.index("password")] = bcrypt.hashpw(vals[cols.index("password")].encode('utf-8'),
                                                         bcrypt.gensalt()).decode('utf-8')

        run_execute(f"UPDATE {table} SET {', '.join([f'{c}=%s' for c in cols])} WHERE {pk}=%s", tuple(vals + [id]))

        if table == 'pacienti':
            mod_prezentare = request.form.get('Mod_prezentare', 'Mijloace Proprii')
            check_sql = "SELECT Id_vizita FROM Vizite_urgente WHERE id_pacient = %s"
            exista_vizita = run_select(check_sql, (id,))

            if exista_vizita:
                run_execute("UPDATE Vizite_urgente SET Mod_prezentare = %s WHERE id_pacient = %s", (mod_prezentare, id))
            else:
                run_insert(
                    "INSERT INTO Vizite_urgente (id_pacient, Mod_prezentare, diagnostic) VALUES (%s, %s, 'Actualizat la editare')",
                    (id, mod_prezentare))

        flash("Actualizat!", "info")
        return redirect(url_for('crud_list', table=table))

    if table == 'pacienti':
        sql = """
              SELECT p.*, v.Mod_prezentare
              FROM pacienti p
                       LEFT JOIN Vizite_urgente v ON p.Id_pacient = v.id_pacient
              WHERE p.Id_pacient = %s
              """
        res = run_select(sql, (id,))
        col_names = [c[0] for c in run_select("SHOW COLUMNS FROM pacienti")] + ['Mod_prezentare']
    else:
        res = run_select(f"SELECT * FROM {table} WHERE {pk}=%s", (id,))
        col_names = [c[0] for c in run_select(f"SHOW COLUMNS FROM {table}")]

    row_dict = {col_names[i]: res[0][i] for i in range(len(col_names))}
    col_map = {name: index for index, name in enumerate(col_names)}

    fk = {f: run_select(f"SELECT {r[1]}, {r[2]} FROM {r[0]}") for f, r in conf.get("fk_dropdowns", {}).items()}
    return render_template("crud_form.html", table=table, config=conf, fk_options=fk, row=row_dict, col_map=col_map)


@app.route("/crud/<table>/delete/<int:id>", methods=["POST"])
def crud_delete(table, id):
    conf = CRUD_CONFIG[table]

    if conf.get("allow_delete") is False:
        flash(f"Acțiune neautorizată! Ștergerea înregistrărilor din tabela '{conf['label']}' este interzisă.", "danger")
        return redirect(url_for('crud_list', table=table))

    pk = conf.get("pk", "id")
    run_execute(f"DELETE FROM {table} WHERE {pk}=%s", (id,))
    flash("Șters!", "warning")
    return redirect(url_for('crud_list', table=table))


@app.route("/pacient/<int:id>/observatii", methods=["GET", "POST"])
def pacient_observatii(id):
    if request.method == "POST":
        run_execute("UPDATE pacienti SET Observatii=%s WHERE Id_pacient=%s", (request.form.get("observatii_text"), id))
        flash("Observații actualizate cu succes!", "success")

    p = run_select("SELECT Id_pacient, Nume, Prenume, Observatii FROM pacienti WHERE Id_pacient=%s", (id,))
    if not p:
        flash("Pacientul nu a fost găsit!", "danger")
        return redirect(url_for('crud_list', table='pacienti'))

    return render_template("observatii.html", pacient=p[0])


@app.route("/api/sqli/query", methods=["POST"])
def api_sqli_query():
    table = (request.form.get("table") or "").strip()
    field = (request.form.get("field") or "").strip()
    value = (request.form.get("value") or "").strip()
    mode = (request.form.get("mode") or "safe").strip().lower()
    limit = 25

    if table not in CRUD_CONFIG:
        return {"ok": False, "error": "Tabel neautorizat!"}, 400

    conf = CRUD_CONFIG[table]
    if field not in conf["list_fields"]:
        return {"ok": False, "error": f"Câmp invalid. Permise: {', '.join(conf['list_fields'])}"}, 400

    try:
        if mode == "unsafe":
            sql = f"SELECT * FROM {table} WHERE {field} = '{value}' LIMIT {limit};"
            rows = run_select(sql)
        else:
            sql = f"SELECT * FROM {table} WHERE {field} = %s LIMIT {limit};"
            rows = run_select(sql, (value,))

        return {
            "ok": True,
            "mode": mode,
            "generated_sql": sql if mode == "unsafe" else sql.replace("%s", f"'{value}'"),
            "count": len(rows),
            "results": [list(r) for r in rows],
            "columns": conf["list_fields"]
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}, 500


@app.route("/glasgow-lab", methods=["GET"])
def glasgow_lab():
    return render_template("glasgow_lab.html")


@app.route("/api/pacienti/adauga", methods=["POST"])
def api_pacienti_adauga():
    nume = request.form.get("nume", "").strip()
    prenume = request.form.get("prenume", "").strip()
    cnp = request.form.get("cnp", "").strip()
    observatii = request.form.get("observatii", "").strip()
    sectia = request.form.get("sectia_selectata", "").strip()
    cabinet = request.form.get("cabinet_selectat", "").strip()

    if not nume or not prenume or not cnp:
        return "Eroare: Numele, Prenumele și CNP-ul sunt obligatorii!", 400
    if not cabinet:
        return "Eroare: Trebuie să selectați vizual un cabinet de pe holul 3D!", 400

    try:
        sql_pacient = """
                      INSERT INTO pacienti (Nume, Prenume, CNP, Observatii, sectia_selectata, cabinet_selectat)
                      VALUES (%s, %s, %s, %s, %s, %s)
                      """
        id_pacient_nou = run_insert(sql_pacient, (nume, prenume, cnp, observatii, sectia.upper(), cabinet))

        diagnostic_triaj = f"Alocat la {sectia.upper()} ({cabinet})"

        sql_vizita = """
                     INSERT INTO Vizite_urgente (id_pacient, diagnostic, Mod_prezentare)
                     VALUES (%s, %s, %s)
                     """
        run_insert(sql_vizita, (id_pacient_nou, diagnostic_triaj, "Mijloace Proprii"))

        return redirect("/search?query=" + cnp)

    except Exception as e:
        return f"Eroare tehnică la salvarea în baza de date: {str(e)}", 500


@app.route("/vizita/<int:id_vizita>")
def detalii_vizita(id_vizita):
    """Rendază corect detaliile vizitei și istoricul de tratamente medicale Read-Only."""
    sql_vizita = "SELECT * FROM Vizite_urgente WHERE Id_vizita = %s"
    res_vizita = run_select(sql_vizita, (id_vizita,))

    if not res_vizita:
        flash("Vizita medicală specificată nu există!", "danger")
        return redirect(url_for('index'))

    col_names_vizita = [c[0] for c in run_select("SHOW COLUMNS FROM Vizite_urgente")]
    vizita_dict = {col_names_vizita[i]: res_vizita[0][i] for i in range(len(col_names_vizita))}

    sql_medicamente = """
                      SELECT nume_medicament, doza, unitate_masura
                      FROM Administrare_Medicamente
                      WHERE id_vizita = %s \
                      """
    res_medicamente = run_select(sql_medicamente, (id_vizita,))

    medicamente_data = []
    if res_medicamente:
        for r in res_medicamente:
            medicamente_data.append({
                "nume_medicament": r[0],
                "doza": r[1],
                "unitate_masura": r[2]
            })

    return render_template("detalii_vizita.html", vizita=vizita_dict, medicamente=medicamente_data)


@app.route("/sqli-lab")
def sqli_lab():
    return render_template("sqli_lab.html")


if __name__ == "__main__":
    app.run(debug=True, port=5000)