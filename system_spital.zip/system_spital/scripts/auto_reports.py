import sys
import time
from pathlib import Path
import subprocess
from datetime import datetime


RUN_EVERY = 10

CYCLES = 3


ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports.py"
OUT_DIR = ROOT / "outputs"


OUT_DIR.mkdir(parents=True, exist_ok=True)
LOG_PATH = OUT_DIR / "audit.log"


def log(msg):
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    line = f"[{timestamp}] {msg}\n"


    if LOG_PATH.exists():
        current_content = LOG_PATH.read_text(encoding="utf-8")
        LOG_PATH.write_text(current_content + line, encoding="utf-8")
    else:
        LOG_PATH.write_text(line, encoding="utf-8")


def main():
    log("SISTEM MANAGEMENT SPITAL - PORNIRE AUTOMATIZARE RAPOARTE")
    print(f"Orchestrator pornit. Se va rula: {REPORTS.name}")
    print(f"Jurnal audit: {LOG_PATH}")

    for i in range(1, CYCLES + 1):
        log(f"Ciclu {i} pornit - Generare rapoarte medicale")


        res = subprocess.run(
            [sys.executable, str(REPORTS)],
            cwd=str(ROOT),
            capture_output=True,
            text=True
        )

        print(f"\n=== Ciclul {i} Executat ===")


        if res.stdout:
            print("OUTPUT RAPORT:\n", res.stdout)

        if res.stderr:
            print("ERORI SEMNALATE:\n", res.stderr)


        if res.returncode != 0:
            log(f"Ciclu {i} EȘUAT (Cod eroare: {res.returncode})")
            print(f"Eroare detectata. Automatizarea a fost oprita.")
            break
        else:
            log(f"Ciclu {i} finalizat cu SUCCES")


        if i < CYCLES:
            print(f"Așteptare {RUN_EVERY} secunde pana la urmatorul ciclu...")
            time.sleep(RUN_EVERY)

    log("SISTEM MANAGEMENT SPITAL - AUTOMATIZARE FINALIZATĂ")
    print("\nProces încheiat. Verifica audit.log pentru detalii.")


if __name__ == "__main__":
    main()