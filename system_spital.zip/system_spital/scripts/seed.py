import random
from faker import Faker
from app.db import run_execute, run_select

fake = Faker('ro_RO')


NUM_PACIENTI = 500
NUM_USERS = 50
NUM_VIZITE = 800
NUM_LOGS = 1200
DOMENII_EMAIL = ["gmail.com", "yahoo.com", "outlook.com"]


STRUCTURA_SPITAL_SEED = {
    "CHIRURGIE": ["CH-01", "CH-02", "CH-03", "CH-04"],
    "INTERNE": ["INT-01", "INT-02", "INT-03", "INT-04"],
    "TRAUMA": ["TRM-01", "TRM-02", "TRM-03", "TRM-04"],
    "CRITIC": ["RES-01", "RES-02", "ATI-01", "ATI-02"],
    "IMAGISTICA": ["RAD-01", "CT-01", "ECO-01", "LAB-01"]
}


SPECIALIZARI_MEDICALE = [
    "Medic Primar UPU",
    "Medic Rezident",
    "Asistent Triaj",
    "Asistent Medical Principal",
    "Medic Specialist Cardiologie",
    "Medic Specialist Chirurgie Generală",
    "Asistent Șef"
]


def reset_and_seed():
    print("=== START REPOPULARE BAZA DE DATE CONFIGURATĂ UPU ===")


    run_execute("SET FOREIGN_KEY_CHECKS = 0;")


    tabele = [
        'Administrare_Medicamente',
        'Semne_vitale',
        'user_log',
        'Vizite_urgente',
        'pacienti',
        'users'
    ]

    for tabel in tabele:
        print(f"Curăț tabelul: {tabel}...")
        run_execute(f"DELETE FROM {tabel};")
        run_execute(f"ALTER TABLE {tabel} AUTO_INCREMENT = 1;")

    run_execute("SET FOREIGN_KEY_CHECKS = 1;")


    print(f"Generez {NUM_USERS} utilizatori medicali...")
    run_execute(
        "INSERT INTO users (username, email, specializare) VALUES (%s, %s, %s);",
        ("admin_spital", "admin@spital.ro", "Administrator Sistem")
    )

    for _ in range(NUM_USERS):
        username = fake.unique.user_name() + str(random.randint(1, 99))
        email = f"{username}@{random.choice(DOMENII_EMAIL)}"
        specializare_aleasa = random.choice(SPECIALIZARI_MEDICALE)

        # Inserăm corect utilizatorul cu tot cu specializarea lui medicală
        run_execute(
            "INSERT INTO users (username, email, specializare) VALUES (%s, %s, %s);",
            (username, email, specializare_aleasa)
        )


    print(f"Generez {NUM_PACIENTI} pacienți cu alocare în holul clinic 3D...")
    sectii_disponibile = list(STRUCTURA_SPITAL_SEED.keys())

    for _ in range(NUM_PACIENTI):
        sectia_aleasa = random.choice(sectii_disponibile)
        cabinet_ales = random.choice(STRUCTURA_SPITAL_SEED[sectia_aleasa])
        observatii_fake = random.choice(
            [fake.sentence(), "Prezintă simptomatologie specifică.", "Necesită monitorizare cardiacă.",
             "Pacient stabil în curs de investigații.", ""])

        run_execute(
            """INSERT INTO pacienti (Nume, Prenume, CNP, Observatii, sectia_selectata, cabinet_selectat)
               VALUES (%s, %s, %s, %s, %s, %s);""",
            (fake.last_name(), fake.first_name(), fake.unique.ssn(), observatii_fake, sectia_aleasa, cabinet_ales)
        )


    res_pacienti = run_select("SELECT Id_pacient FROM pacienti;")
    pacient_ids = [row[0] for row in res_pacienti]


    print(f"Generez {NUM_VIZITE} vizite medicale de urgență...")
    moduri_prezentare = [
        "Ambulantă SAJ",
        "Echipaj SMURD",
        "Mijloace Proprii",
        "Poliție / Jandarmerie",
        "Transfer Interspitalicesc"
    ]

    for p_id in pacient_ids:
        mod = random.choice(moduri_prezentare)
        data_random = fake.date_time_between(start_date='-7d', end_date='now')
        run_execute(
            "INSERT INTO Vizite_urgente (id_pacient, Data_ora_sosirie, Mod_prezentare, diagnostic) VALUES (%s, %s, %s, %s);",
            (p_id, data_random, mod, "Diagnostic general stabilit la triaj initial.")
        )

    vizite_ramase = NUM_VIZITE - NUM_PACIENTI
    if vizite_ramase > 0:
        for _ in range(vizite_ramase):
            mod = random.choice(moduri_prezentare)
            data_random = fake.date_time_between(start_date='-7d', end_date='now')
            p_id = random.choice(pacient_ids)
            run_execute(
                "INSERT INTO Vizite_urgente (id_pacient, Data_ora_sosirie, Mod_prezentare, diagnostic) VALUES (%s, %s, %s, %s);",
                (p_id, data_random, mod, "Re-evaluare clinică în regim de urgență.")
            )


    vizite = run_select("SELECT Id_vizita FROM Vizite_urgente;")
    lista_medicamente = ["Algocalmin", "Paracetamol", "Adrenalina", "Glucoza 5%", "Diazepam", "Morfina", "Aspirina"]

    print("Generez semne vitale și administrări medicamente...")
    for (id_v,) in vizite:
        run_execute(
            """INSERT INTO Semne_vitale
                   (Id_vizita, Tensiune_arteriala, Puls, Temperatura, Saturatie, Scor_GCS)
               VALUES (%s, %s, %s, %s, %s, %s);""",
            (id_v, f"{random.randint(90, 180)}/{random.randint(60, 110)}",
             random.randint(50, 140), round(random.uniform(35.5, 39.8), 1),
             random.randint(85, 100), random.randint(3, 15))
        )

        for _ in range(random.randint(1, 2)):
            run_execute(
                "INSERT INTO Administrare_Medicamente (id_vizita, nume_medicament, doza, unitate_masura) VALUES (%s, %s, %s, %s);",
                (id_v, random.choice(lista_medicamente), str(random.randint(1, 500)),
                 random.choice(['mg', 'ml', 'fiole']))
            )


    print(f"Simulez {NUM_LOGS} acțiuni în user_log...")
    res_users = run_select("SELECT id FROM users;")
    user_ids = [row[0] for row in res_users]
    actiuni = ["Log-in", "Vizualizare fisa pacient", "Actualizare semne vitale", "Export raport triaj", "Log-out"]

    for _ in range(NUM_LOGS):
        u_id = random.choice(user_ids)
        actiune = random.choice(actiuni)
        run_execute("INSERT INTO user_log (user_id, action) VALUES (%s, %s);", (u_id, actiune))

    print("\n=== SUCCES: Baza de date a fost repopulată și sincronizată complet! ===")


if __name__ == "__main__":
    reset_and_seed()