import json
from pathlib import Path
from app.db import run_select


sql = """
SELECT 
    u.id, 
    u.username, 
    u.email,
    COUNT(l.id) AS total_actiuni
FROM users u
LEFT JOIN user_log l ON u.id = l.user_id
GROUP BY u.id, u.username, u.email
ORDER BY u.id;
"""


rows = run_select(sql)

data = []
for r in rows:
    data.append({
        "id": r[0],
        "utilizator": r[1],
        "email": r[2],
        "activitate_log": int(r[3]) if r[3] is not None else 0
    })


out_path = Path("outputs") / "activitate_utilizatori.json"
out_path.parent.mkdir(exist_ok=True)


out_path.write_text(
    json.dumps(data, indent=2, ensure_ascii=False),
    encoding="utf-8"
)

print(f"Fisierul salvat in: {out_path}")