from app.db import run_execute
from scripts.create_tables import create_tables


run_execute("DROP TABLE IF EXISTS Semne_vitale;")
run_execute("DROP TABLE IF EXISTS user_log;")

run_execute("DROP TABLE IF EXISTS Vizite_urgente;")
run_execute("DROP TABLE IF EXISTS users;")

create_tables()

