from pathlib import Path
from app.db import get_connection


def create_tables():
    project_root = Path(__file__).resolve().parent.parent
    conn = get_connection()
    if not conn:
        print("Eroare: Nu s-a putut stabili conexiunea la baza de date.")
        return

    cur = conn.cursor()

    try:

        schema_path = project_root / "sql" / "schema.sql"
        if schema_path.exists():
            sql_text = schema_path.read_text(encoding="utf-8")

            statements = [s.strip() for s in sql_text.split(";") if s.strip()]
            for stmt in statements:
                try:
                    cur.execute(stmt)
                except Exception as e_stmt:
                    print(f"Eroare la comanda: {stmt[:50]}... \nDetalii: {e_stmt}")
                    raise e_stmt
            print("OK: Tabelele au fost create cu succes!")


        triggers_path = project_root / "sql" / "triggers.sql"
        if triggers_path.exists():
            triggers_text = triggers_path.read_text(encoding="utf-8")
            trigger_blocks = [b.strip() for b in triggers_text.split("-- TRIGGER_END") if b.strip()]
            for block in trigger_blocks:
                if block:
                    cur.execute(block)
            print("OK: Triggerele au fost create cu succes!")


        procedures_path = project_root / "sql" / "procedures.sql"
        if procedures_path.exists():
            proc_text = procedures_path.read_text(encoding="utf-8")

            proc_blocks = [b.strip() for b in proc_text.split("-- PROC_END") if b.strip()]

            for block in proc_blocks:
                # Filtrăm liniile de DELIMITER care dau eroare în Python
                lines = [line for line in block.splitlines()
                         if not line.strip().upper().startswith("DELIMITER")]
                clean_block = "\n".join(lines).strip()

                if clean_block:
                    cur.execute(clean_block)
            print("OK: Procedurile stocate au fost create cu succes!")

        conn.commit()
        print("\nTOTUL A MERS OK! ")

    except Exception as e:
        if conn:
            conn.rollback()
        print("\n[EROARE CRITICA]:", e)
    finally:
        if cur: cur.close()
        if conn: conn.close()


if __name__ == "__main__":
    create_tables()