import json
from pathlib import Path
from app.db import run_select


TEMP_ALERTA = 38.0
SATURATIE_CRITICA = 92


sql = """
SELECT 
    v.Id_vizita, 
    v.Mod_prezentare, 
    s.Temperatura, 
    s.Saturatie,
    s.Tensiune_arteriala
FROM Vizite_urgente v
JOIN Semne_vitale s ON v.Id_vizita = s.Id_vizita
WHERE s.Temperatura > %s OR s.Saturatie < %s
ORDER BY s.Temperatura DESC;
"""


rows = run_select(sql, (TEMP_ALERTA, SATURATIE_CRITICA))

alerte = []
for r in rows:
    alerte.append({
        "id_vizita": r[0],
        "mod_sosire": r[1],
        "parametri_clinici": {
            "temperatura": float(r[2]),
            "oxigen": r[3],
            "tensiune": r[4]
        },
        "status_alerta": "CRITIC"
    })

out_path = Path("outputs") / "alerte_triaj_critic.json"
out_path.parent.mkdir(exist_ok=True)

out_path.write_text(json.dumps({
    "descriere": "Pacienti care depășesc pragurile de siguranta",
    "total_alerte": len(alerte),
    "lista_urgente": alerte
}, indent=4, ensure_ascii=False), encoding="utf-8")

print(f"Raport de alerte generat: {out_path}")