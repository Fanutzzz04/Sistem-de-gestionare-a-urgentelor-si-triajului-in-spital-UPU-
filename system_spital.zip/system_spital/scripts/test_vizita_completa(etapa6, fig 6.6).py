import json
from app.db import get_connection, run_select

print("=== SERVICIU INREGISTRARE VIZITA URGENTA ===")


pacient_data = run_select("SELECT Id_pacient, Nume FROM pacienti LIMIT 1;")

if not pacient_data:
    print("EROARE: Nu am gasit niciun pacient in baza de date. Ruleaza seed.py mai intai!")
    exit()

id_pacient = pacient_data[0][0]
nume_pacient = pacient_data[0][1]


medicamente = [
    {"nume": "Algocalmin", "doza": "500", "unitate": "mg"},
    {"nume": "Diazepam", "doza": "10", "unitate": "mg"},
    {"nume": "Ser Fiziologic", "doza": "250", "unitate": "ml"}
]

medicamente_json = json.dumps(medicamente)

print(f"Apelam procedura pentru pacientul: {nume_pacient} (ID: {id_pacient})...")

conn = get_connection()
cur = conn.cursor()

try:

    cur.execute("CALL inregistreaza_vizita_completa(%s, %s, %s);",
                (id_pacient, "Prezentare prin Ambulanta", medicamente_json))


    row = cur.fetchone()
    id_vizita = row[0]


    while cur.nextset():
        if cur.description is not None:
            cur.fetchall()

    conn.commit()
    print(f"OK: Vizita inregistrata cu succes. ID Vizita: {id_vizita}")

except Exception as e:
    print(f"EROARE CRITICA: {e}")
    conn.rollback()
finally:
    cur.close()
    conn.close()


print("\nVerificare in baza de date (Administrare_Medicamente)")
rows = run_select("""
    SELECT v.Id_vizita, m.nume_medicament, m.doza, m.unitate_masura
    FROM Vizite_urgente v
    JOIN Administrare_Medicamente m ON v.Id_vizita = m.id_vizita
    WHERE v.Id_vizita = %s
""", (id_vizita,))

for r in rows:
    print(f"Vizita #{r[0]} | Medicament: {r[1]} | Doza: {r[2]} {r[3]}")