from app.db import run_select


query = """
SELECT 
    v.Id_vizita, 
    v.Mod_prezentare, 
    s.Tensiune_arteriala, 
    s.Puls, 
    s.Temperatura
FROM Vizite_urgente v
JOIN Semne_vitale s ON v.Id_vizita = s.Id_vizita
LIMIT 5;
"""

rezultat = run_select(query)

print(f"{'ID':<5} | {'Mod Prezentare':<25} | {'TA':<10} | {'Puls':<5} | {'Temp':<5}")
print("-" * 60)
for r in rezultat:
    print(f"{str(r[0]):<5} | {str(r[1]):<25} | {str(r[2]):<10} | {str(r[3]):<5} | {str(r[4]):<5}")







