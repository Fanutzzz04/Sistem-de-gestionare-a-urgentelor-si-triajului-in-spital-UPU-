import time
from app.db import run_execute


def apply_indexes():


    index_queries = [
        "CREATE INDEX IF NOT EXISTS idx_pacienti_nume ON pacienti(Nume);",
        "CREATE INDEX IF NOT EXISTS idx_med_nume ON Administrare_Medicamente(nume_medicament);",
        "CREATE INDEX IF NOT EXISTS idx_vizite_pacient ON Vizite_urgente(id_pacient);"
    ]

    for query in index_queries:

        index_name = query.split(" ")[4]
        print(f"Rulam: {index_name}...")

        try:
            start_time = time.time()
            run_execute(query)
            end_time = time.time()

            duration = (end_time - start_time) * 1000
            print(f"Succes! (Durata creare: {duration:.2f} ms)\n")

        except Exception as e:
            print(f"Eroare la crearea indexului: {e}\n")

    print("Toate optimizarile planificate au fost procesate.")
    print("-" * 50)


if __name__ == "__main__":
    apply_indexes()