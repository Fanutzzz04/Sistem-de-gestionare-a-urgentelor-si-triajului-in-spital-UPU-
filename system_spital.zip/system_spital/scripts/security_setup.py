import mariadb
import bcrypt
import sys


DB_HOST = "127.0.0.1"
DB_PORT = 3306
DB_NAME = "spital_db"
ROOT_USER = "root"
ROOT_PASS = "rootpassword"


def get_root_connection():
    try:
        return mariadb.connect(
            host=DB_HOST, port=DB_PORT, user=ROOT_USER,
            password=ROOT_PASS, database=DB_NAME
        )
    except mariadb.Error as e:
        print(f"[EROARE] Nu s-a putut conecta la MariaDB: {e}")
        sys.exit(1)


def hash_password(plain: str) -> str:
    """Generează un hash bcrypt valid."""
    return bcrypt.hashpw(plain.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')


def setup_security():
    conn = get_root_connection()
    cur = conn.cursor()

    print("--- Pasul 1: Configurarea permisiunilor de sistem ---")
    db_users = [
        ("manager", "manager123", "ALL PRIVILEGES"),
        ("insert_user", "insert123", "SELECT, INSERT"),
    ]

    for user, pwd, priv in db_users:
        try:
            cur.execute(f"DROP USER IF EXISTS '{user}'@'%'")
            cur.execute(f"CREATE USER '{user}'@'%' IDENTIFIED BY '{pwd}'")
            cur.execute(f"GRANT {priv} ON {DB_NAME}.* TO '{user}'@'%'")
            print(f"[OK] Utilizator DB configurat: {user}")
        except mariadb.Error as e:
            print(f"[NOTĂ] Eroare la crearea utilizatorului {user}: {e}")

    print("\n--- Pasul 2: Securizarea parolelor din tabelul 'users' ---")
    try:
        cur.execute("SELECT id, password FROM users")
        rows = cur.fetchall()

        for user_id, pwd in rows:
            if pwd and not str(pwd).startswith("$2b$"):
                hashed = hash_password(str(pwd))
                cur.execute("UPDATE users SET password=%s WHERE id=%s", (hashed, user_id))
                print(f"[MODIFICAT] ID {user_id}: Parola a fost transformată în HASH.")
            else:
                print(f"[SKIP] ID {user_id}: Parola este deja securizată.")

    except mariadb.Error as e:
        print(f"[EROARE] Eroare la procesarea tabelului users: {e}")

    cur.execute("FLUSH PRIVILEGES")
    conn.commit()
    conn.close()
    print("\n[FINISH] Sistemul este acum securizat și gata pentru Etapa 10.")


if __name__ == "__main__":
    setup_security()