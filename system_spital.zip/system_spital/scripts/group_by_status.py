import json
from pathlib import Path
from app.db import run_select


sql = """
SELECT 
    v.Mod_prezentare,
    COUNT(*) AS total_pacienti,
    AVG(s.Scor_GCS) AS medie_gcs
FROM Vizite_urgente v
JOIN Semne_vitale s ON v.Id_vizita = s.Id_vizita
GROUP BY v.Mod_prezentare
ORDER BY total_pacienti DESC;
"""

rows = run_select(sql)

data = []
for r in rows:
    data.append({
        "mod_prezentare": r[0],
        "numar_cazuri": int(r[1]),
        "gravitate_medie_gcs": float(r[2]) if r[2] is not None else 15.0
    })


out_path = Path("outputs") / "statistici_triaj.json"
out_path.parent.mkdir(exist_ok=True)

out_path.write_text(
    json.dumps(data, indent=2, ensure_ascii=False),
    encoding="utf-8"
)

print(f"JSON salvat: {out_path}")