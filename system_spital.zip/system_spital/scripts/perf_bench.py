import time
import statistics
from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np
from app.db import run_select, run_execute

RUNS = 50

OUTPUT_DIR = Path(__file__).resolve().parent.parent / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)
CHART_FILE = OUTPUT_DIR / "performanta_spital_chart.png"

TEST_QUERIES = [
    {
        "name": "Cautare Pacient dupa Nume",
        "sql": "SELECT * FROM pacienti WHERE Nume = %s;",
        "params": ("Ionescu",),
    },
    {
        "name": "Cautare Medicament dupa Nume",
        "sql": "SELECT * FROM Administrare_Medicamente WHERE nume_medicament = %s;",
        "params": ("Adrenalina",),
    }
]

INDEX_SQL = [
    "CREATE INDEX IF NOT EXISTS idx_pacienti_nume ON pacienti(Nume);",
    "CREATE INDEX IF NOT EXISTS idx_med_nume ON Administrare_Medicamente(nume_medicament);",
]

def benchmark_query(sql, params, runs):
    times = []
    for _ in range(runs):
        start = time.perf_counter()
        try:
            run_select(sql, params)
        except Exception as e:
            print(f"Eroare la executie: {e}")
            return [0]
        end = time.perf_counter()
        times.append((end - start) * 1000)
    return times

def run_suite(label):
    results = {}
    for q in TEST_QUERIES:
        times = benchmark_query(q["sql"], q["params"], RUNS)
        avg = statistics.mean(times) if times else 0
        results[q["name"]] = {"avg": avg}
        # Modificat aici: %.2f pentru consola
        print(f"[{label}] {q['name']} -> medie {avg:.2f} ms")
    return results

def apply_indexes():
    print("\n--- Se aplica optimizarile (Indecsi) ---")
    for stmt in INDEX_SQL:
        try:
            run_execute(stmt)
        except Exception as e:
            print(f"Nota: Indexul poate exista deja sau tabelul lipseste: {e}")

def generate_chart(before_results, after_results):
    labels = list(before_results.keys())
    before_means = [before_results[name]["avg"] for name in labels]
    after_means = [after_results[name]["avg"] for name in labels]

    x = np.arange(len(labels))
    width = 0.35

    fig, ax = plt.subplots(figsize=(10, 6))
    rects1 = ax.bar(x - width / 2, before_means, width, label='Inainte de Index', color='#e74c3c')
    rects2 = ax.bar(x + width / 2, after_means, width, label='Dupa Index', color='#2ecc71')

    ax.set_ylabel('Timp mediu (ms)')
    ax.set_title('Analiza Performantei Interogarilor - Etapa 5')
    ax.set_xticks(x)
    ax.set_xticklabels(labels)
    ax.legend()


    ax.bar_label(rects1, padding=3, fmt='%.2f')
    ax.bar_label(rects2, padding=3, fmt='%.2f')

    plt.tight_layout()
    plt.savefig(CHART_FILE)
    print(f"\nGrafic salvat cu succes: {CHART_FILE}")
    plt.show()

def main():
    print("START BENCHMARK PERFORMANTA")

    before = run_suite("BEFORE")
    apply_indexes()
    after = run_suite("AFTER")

    generate_chart(before, after)
    print("\n TEST FINALIZAT ")

if __name__ == "__main__":
    main()