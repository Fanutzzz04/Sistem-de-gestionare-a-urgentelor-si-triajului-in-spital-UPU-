import json
import csv
import matplotlib.pyplot as plt
from pathlib import Path
from decimal import Decimal
from datetime import datetime


from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Image, Table, TableStyle
)
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import inch

from app.db import run_select


OUT_DIR = Path("outputs")
OUT_DIR.mkdir(exist_ok=True)


LOGO_PATH = Path("scripts/logo_fiir.jpg")


def normalize(v):
    if isinstance(v, Decimal):
        x = float(v)
        return int(x) if x.is_integer() else x
    return v


def export_data(data, fields, base_name):
    csv_path = OUT_DIR / f"{base_name}.csv"
    json_path = OUT_DIR / f"{base_name}.json"


    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(data)

    # Export JSON [cite: 140]
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

    return csv_path, json_path


def generate_chart(data, x_key, y_key, title, base_name):
    chart_path = OUT_DIR / f"{base_name}_chart.png"

    names = [str(d[x_key]) for d in data]
    values = [d[y_key] for d in data]

    plt.figure(figsize=(10, 6))
    plt.bar(names, values, color='#3498db')
    plt.title(title)
    plt.xlabel("Diagnostic")
    plt.ylabel("Număr Cazuri")
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    plt.savefig(str(chart_path))
    plt.close()
    return chart_path


def generate_pdf(data, fields, title, description, chart_path, base_name):
    pdf_path = OUT_DIR / f"{base_name}.pdf"
    doc = SimpleDocTemplate(str(pdf_path), pagesize=A4)
    elements = []
    styles = getSampleStyleSheet()

    title_style = ParagraphStyle(name="TitleStyle", parent=styles["Heading1"], fontSize=18, spaceAfter=20)

    if LOGO_PATH.exists():
        logo = Image(str(LOGO_PATH), width=1.2 * inch, height=1.2 * inch)
        elements.append(logo)
        elements.append(Spacer(1, 10))

    elements.append(Paragraph(title, title_style))
    elements.append(Spacer(1, 10))
    elements.append(Paragraph(description, styles["Normal"]))
    elements.append(Spacer(1, 20))

    table_data = [[f.replace('_', ' ').title() for f in fields]]
    for d in data:
        table_data.append([d[f] for f in fields])

    table = Table(table_data, colWidths=[3.5 * inch, 1.5 * inch])
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2c3e50")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("ALIGN", (1, 0), (-1, -1), "CENTER"),
        ("BACKGROUND", (0, 1), (-1, -1), colors.HexColor("#ecf0f1")),
    ]))

    elements.append(table)
    elements.append(Spacer(1, 25))

    if chart_path.exists():
        chart_img = Image(str(chart_path), width=6 * inch, height=3.5 * inch)
        elements.append(chart_img)

    doc.build(elements)
    return pdf_path


def report_diagnostice():
    sql = """
          SELECT diagnostic, COUNT(*) as nr_cazuri
          FROM Vizite_urgente
          WHERE diagnostic IS NOT NULL
          GROUP BY diagnostic
          ORDER BY nr_cazuri DESC LIMIT 10 \
          """
    rows = run_select(sql)
    data = [{"diagnostic": r[0], "nr_cazuri": normalize(r[1])} for r in rows]

    fields = ["diagnostic", "nr_cazuri"]
    name = "Raport_Top_Diagnostice"

    export_data(data, fields, name)
    c_path = generate_chart(data, "diagnostic", "nr_cazuri", "Top 10 Diagnostice Urgență", name)
    generate_pdf(data, fields, "Analiza Diagnosticelor - UPU",
                 "Raport generat pentru monitorizarea incidentei afectiunilor.", c_path, name)


def report_mod_prezentare():

    sql = """
          SELECT Mod_prezentare, COUNT(*) as total
          FROM Vizite_urgente
          GROUP BY Mod_prezentare
          ORDER BY total DESC \
          """
    rows = run_select(sql)
    data = [{"mod_prezentare": r[0], "total": normalize(r[1])} for r in rows]

    fields = ["mod_prezentare", "total"]
    name = "Raport_Mod_Prezentare"

    export_data(data, fields, name)
    c_path = generate_chart(data, "mod_prezentare", "total", "Mod de Sosire Pacienti", name)
    generate_pdf(data, fields, "Raport Mod Prezentare",
                 "Analiza modului în care pacientii ajung la spital.", c_path, name)


def main():
    print("Generare rapoarte Business Intelligence...")
    report_diagnostice()
    report_mod_prezentare()
    print(f"Succes! Fisierele sunt in: {OUT_DIR.resolve()}")


if __name__ == "__main__":
    main()