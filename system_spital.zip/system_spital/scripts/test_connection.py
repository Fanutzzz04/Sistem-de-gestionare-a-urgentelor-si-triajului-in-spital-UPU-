import sys
import os


sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from app.db import run_select

result = run_select(
    "SELECT DATABASE() AS db_name, 'Conexiunea a avut loc cu succes!' AS status;"
)

print(result)


