from app.db import run_execute, run_select

print("--- TEST TRIGGER BEFORE INSERT (Administrare_Medicamente) ---")


vizita = run_select("SELECT Id_vizita FROM Vizite_urgente LIMIT 1;")
if not vizita:
    print("EROARE: Nu exista vizite pentru testare. Ruleaza seed.py!")
    exit()

id_v = vizita[0][0]

print(f"Inserare valida (doza = 5.0 mg)")
try:
    sql_valid = "INSERT INTO Administrare_Medicamente (id_vizita, nume_medicament, doza_mg, locatie_administrare) VALUES (%s, %s, %s, %s);"
    run_execute(sql_valid, (id_v, "TestMed", 5.0, "Spital"))
    print("OK: Inserarea valida a reusit")
except Exception as e:
    print("EROARE (nu trebuia sa apara):", e)

print(f"\nInserare invalida (doza = -2.0 mg)")
try:
    sql_invalid = "INSERT INTO Administrare_Medicamente (id_vizita, nume_medicament, doza_mg, locatie_administrare) VALUES (%s, %s, %s, %s);"
    run_execute(sql_invalid, (id_v, "TestMed", -2.0, "Spital"))
    print("EROARE: Inserarea invalida a trecut (triggerul NU functioneaza)")
except Exception as e:
    print("OK: Inserarea invalida a fost respinsa de trigger")
    print("Mesaj MariaDB:", e)

print("\nTEST TRIGGER AFTER UPDATE (Vizite_urgente)")
run_execute("UPDATE Vizite_urgente SET Mod_prezentare = 'Ambulanta-Test' WHERE Id_vizita = %s", (id_v,))

print("Verificam jurnalul de activitate (user_log)...")
logs = run_select("SELECT action FROM user_log ORDER BY id DESC LIMIT 2;")
for l in logs:
    print("-", l[0])

print("\nTEST TRIGGERE FINALIZAT CU SUCCES")