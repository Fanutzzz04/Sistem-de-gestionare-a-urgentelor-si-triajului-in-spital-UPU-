\# Sistem Gestiune Spital (Modul UPU)



Acesta este un proiect pentru facultate (Etapele finale 7-10) care simuleaza gestionarea unei Unitati de Primiri Urgente (UPU). Aplicatia are o interfata grafica web moderna, cu tematica dark-mode, si este conectata la o baza de date MariaDB.



\## Ce stie sa faca aplicatia:



\* \*\*Pagina principala (Dashboard):\*\* Arata statistici live cu numarul de utilizatori (medici), pacienti, urgente si medicamente. Include si grafice pentru repartizarea pe sectii si modurile de sosire ale pacientilor (ambulanta, mijloace proprii etc.).

\* \*\*Sistem CRUD complet:\*\* Permite adaugarea, vizualizarea, editarea si stergerea pacientilor si a fiselor de urgente direct din interfata.

\* \*\*Modul Administrare Medicamente (Read-Only):\*\* Afiseaza tratamentele pe care pacientii le-au primit deja in ambulanta sau acasa. Datele din aceasta tabela sunt setate doar pentru citire (nu se pot edita sau sterge din aplicatie), deoarece logica proiectului presupune ca ele vin automat de la echipajele de pe teren.

\* \*\*Securitate:\*\* Parolele din tabela `users` sunt stocate securizat sub forma de hash-uri prin `bcrypt`. Toate interogarile SQL folosesc parametrizare pentru a bloca atacurile de tip SQL Injection.



\## Tehnologii folosite:



\* \*\*Backend:\*\* Python, Flask

\* \*\*Baza de date:\*\* MariaDB

\* \*\*Securitate:\*\* Bcrypt

\* \*\*Frontend:\*\* HTML, CSS, JavaScript (cu libraria Chart.js pentru grafice)



\## Cum se instaleaza si cum se ruleaza proiectul:



\## Cum se instaleaza si cum se ruleaza proiectul:



1\. \*\*Configurarea bazei de date:\*\*

  \* Importa fisierul SQL primit (baza de date `spital\_db`) in serverul tau local de MariaDB. 

 \* Datele de conectare la baza de date sunt preconfigurate in `app/db.py` pe serverul local (localhost, user: root).



2\. \*\*Instalarea librariilor:\*\*

 \* Deschide terminalul din PyCharm si ruleaza urmatoarea comanda pentru a instala toate dependentele necesare:

  ```bash

 pip install -r requirements.txt



DATE PENTRU LOGARE (panou login)



username: admin_spital

password: spital2026





