DROP TRIGGER IF EXISTS log_vizita_noua;
-- TRIGGER_END

CREATE TRIGGER log_vizita_noua
AFTER INSERT ON Vizite_urgente
FOR EACH ROW
BEGIN

    INSERT INTO user_log (user_id, action)
    VALUES (1, CONCAT('Pacient nou inregistrat: ', NEW.id_pacient));
END;
-- TRIGGER_END