DROP PROCEDURE IF EXISTS inregistreaza_vizita_completa;
-- PROC_END

CREATE PROCEDURE inregistreaza_vizita_completa(
    IN p_id_pacient INT,
    IN p_mod_prezentare VARCHAR(100),
    IN p_medicamente_json JSON
)
BEGIN
    DECLARE v_id_vizita INT;
    DECLARE v_i INT DEFAULT 0;
    DECLARE v_len INT DEFAULT 0;
    DECLARE v_nume_med VARCHAR(255);
    DECLARE v_doza VARCHAR(50);
    DECLARE v_unitate VARCHAR(20);


    INSERT INTO Vizite_urgente(id_pacient, Mod_prezentare, Data_ora_sosirie)
    VALUES (p_id_pacient, p_mod_prezentare, NOW());


    SET v_id_vizita = LAST_INSERT_ID();
    SET v_len = JSON_LENGTH(p_medicamente_json);


    WHILE v_i < v_len DO
        SET v_nume_med = JSON_UNQUOTE(JSON_EXTRACT(p_medicamente_json, CONCAT('$[', v_i, '].nume')));
        SET v_doza = JSON_UNQUOTE(JSON_EXTRACT(p_medicamente_json, CONCAT('$[', v_i, '].doza')));
        SET v_unitate = JSON_UNQUOTE(JSON_EXTRACT(p_medicamente_json, CONCAT('$[', v_i, '].unitate')));

        INSERT INTO Administrare_Medicamente(id_vizita, nume_medicament, doza, unitate_masura)
        VALUES (v_id_vizita, v_nume_med, v_doza, v_unitate);

        SET v_i = v_i + 1;
    END WHILE;

    SELECT v_id_vizita AS id_vizita_creata;
END;
-- PROC_END