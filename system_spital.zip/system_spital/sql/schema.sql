USE spital_db;

CREATE TABLE IF NOT EXISTS pacienti (
    Id_pacient INT AUTO_INCREMENT PRIMARY KEY,
    Nume VARCHAR(100) NOT NULL,
    Prenume VARCHAR(100) NOT NULL,
    CNP CHAR(13) UNIQUE NOT NULL
);

CREATE TABLE IF NOT EXISTS Vizite_urgente (
    Id_vizita INT AUTO_INCREMENT PRIMARY KEY,
    id_pacient INT NOT NULL,
    Mod_prezentare VARCHAR(100),
    Data_ora_sosirie DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_vizita_pacient FOREIGN KEY (id_pacient) REFERENCES pacienti(Id_pacient) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS Administrare_Medicamente (
    id_administrare INT AUTO_INCREMENT PRIMARY KEY,
    id_vizita INT NOT NULL,
    nume_medicament VARCHAR(255) NOT NULL,
    doza VARCHAR(50),
    unitate_masura VARCHAR(20),
    CONSTRAINT fk_med_vizita FOREIGN KEY (id_vizita) REFERENCES Vizite_urgente(Id_vizita) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS Semne_vitale (
    Id_semne_vitale INT AUTO_INCREMENT PRIMARY KEY,
    Id_vizita INT NOT NULL,
    Tensiune_arteriala VARCHAR(20),
    Puls INT,
    Temperatura DECIMAL(4,1),
    Saturatie INT,
    Scor_GCS INT,
    CONSTRAINT fk_semne_vizita FOREIGN KEY (Id_vizita) REFERENCES Vizite_urgente(Id_vizita) ON DELETE CASCADE
);