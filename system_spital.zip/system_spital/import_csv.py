import csv
from pathlib import Path
from app.db import get_connection


ALLOWED_TABLES = {"users", "pacienti", "Vizite_urgente"}


AUTO_SKIP_COLS = {"id", "Id_pacient", "created_at", "move_time"}


def get_table_columns(cur, table: str) -> set[str]:
    cur.execute(f"DESCRIBE {table};")
    return {row[0] for row in cur.fetchall()}


def import_table_from_csv(table: str, csv_path: Path, truncate_first: bool = False):
    table = table.strip()


    if table not in ALLOWED_TABLES:
        raise ValueError(f"Tabel invalid. Alege din: {sorted(ALLOWED_TABLES)}")
    if not csv_path.exists():
        raise FileNotFoundError(f"Nu exista CSV la calea: {csv_path}")

    conn = get_connection()
    cur = conn.cursor()
    inserted = 0
    skipped = 0

    try:
        table_cols = get_table_columns(cur, table)

        with csv_path.open(mode="r", encoding="utf-8", newline="") as f:
            reader = csv.DictReader(f)
            if not reader.fieldnames:
                raise ValueError("CSV invalid: lipseste header-ul.")


            cols = []
            for c in reader.fieldnames:
                c = c.strip()
                if c in AUTO_SKIP_COLS:
                    continue
                if c in table_cols:
                    cols.append(c)

            if not cols:
                raise ValueError("Nu am coloane importabile compatibile.")


            placeholders = ", ".join(["%s"] * len(cols))
            col_list = ", ".join(cols)
            sql = f"INSERT INTO {table} ({col_list}) VALUES ({placeholders});"


            conn.begin()

            if truncate_first:
                cur.execute("SET FOREIGN_KEY_CHECKS = 0;")
                cur.execute(f"TRUNCATE TABLE {table};")
                cur.execute("SET FOREIGN_KEY_CHECKS = 1;")

            for row in reader:
                values = []
                empty_row = True
                for c in cols:
                    val = row.get(c)
                    if val is not None:
                        val = val.strip()


                    if val == "" or val is None:
                        values.append(None)
                    else:
                        values.append(val)
                        empty_row = False

                if empty_row:
                    skipped += 1
                    continue

                cur.execute(sql, tuple(values))
                inserted += 1


            conn.commit()
            print(f"IMPORT OK -> table={table}, inserted={inserted}, skipped={skipped}")

    except Exception as e:
        conn.rollback()
        print(f"IMPORT FAIL -> rollback executat. Eroare: {e}")
        raise
    finally:
        cur.close()
        conn.close()


if __name__ == "__main__":
    t = input(f"Tabel ({', '.join(sorted(ALLOWED_TABLES))}): ").strip()
    p = input("Cale CSV (ex: exports/pacienti.csv): ").strip()
    tr = input("Golesc tabelul inainte? (y/n): ").strip().lower() == 'y'

    import_table_from_csv(t, Path(p), truncate_first=tr)